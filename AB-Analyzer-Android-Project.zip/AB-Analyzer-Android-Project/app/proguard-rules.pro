# No custom obfuscation rules are required for the current debug build.

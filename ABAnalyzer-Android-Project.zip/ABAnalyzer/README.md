# AB Analyzer

Android app for manual Teen Patti card entry, hand ranking, A-vs-B comparison, and local round history.

## Build
Open this folder as an Android project in Android Studio, or push it to GitHub and run **Actions → Build AB Analyzer APK**. The workflow uploads `app-debug.apk` as an artifact.

## Important
This version compares manually entered cards. It does not guarantee predictions of random game outcomes. Screenshot-based card recognition is not included in this first build.

package com.abanalyzer.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private final String[] ranks = {"2","3","4","5","6","7","8","9","10","J","Q","K","A"};
    private final String[] suits = {"♠","♥","♦","♣"};
    private final ArrayList<String> history = new ArrayList<>();
    private Spinner[] aRank = new Spinner[3], aSuit = new Spinner[3], bRank = new Spinner[3], bSuit = new Spinner[3];
    private TextView result, historyView;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(7,19,15));
        getWindow().setNavigationBarColor(Color.rgb(7,19,15));
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = new LinearLayout(this); page.setOrientation(1);
        page.setPadding(dp(20),dp(22),dp(20),dp(28)); page.setBackgroundColor(Color.rgb(7,19,15));
        scroll.addView(page); setContentView(scroll);

        TextView brand = text("AB ANALYZER", 27, "#FFFFFF", true);
        page.addView(brand);
        TextView sub = text("TEEN PATTI • HAND COMPARISON", 12, "#8CA99A", true);
        sub.setPadding(0,dp(4),0,dp(22)); page.addView(sub);

        addSection(page, "PLAYER A");
        for(int i=0;i<3;i++){ LinearLayout row = row(); page.addView(row); aRank[i]=spinner(ranks); aSuit[i]=spinner(suits); row.addView(aRank[i],weight()); row.addView(space(8)); row.addView(aSuit[i],weight()); }
        addSection(page, "PLAYER B");
        for(int i=0;i<3;i++){ LinearLayout row = row(); page.addView(row); bRank[i]=spinner(ranks); bSuit[i]=spinner(suits); row.addView(bRank[i],weight()); row.addView(space(8)); row.addView(bSuit[i],weight()); }
        Button compare = new Button(this); compare.setText("COMPARE HANDS"); compare.setTextColor(Color.WHITE); compare.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(22,163,74)));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1,dp(54)); bp.setMargins(0,dp(20),0,dp(12)); page.addView(compare,bp);
        result = text("Select both players' 3 cards, then compare.",15,"#D8E7DE",false); result.setPadding(dp(14),dp(14),dp(14),dp(14)); result.setBackgroundColor(Color.rgb(17,36,27)); page.addView(result);
        compare.setOnClickListener(v -> compareHands());

        addSection(page, "ROUND HISTORY");
        historyView = text("No rounds saved yet.",13,"#A9BDB1",false); page.addView(historyView);
        Button clear = new Button(this); clear.setText("CLEAR HISTORY"); clear.setTextColor(Color.WHITE); clear.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(54,75,63))); page.addView(clear);
        clear.setOnClickListener(v -> {history.clear(); refreshHistory();});
        TextView note = text("Note: This app ranks entered cards. Random game outcomes cannot be predicted or guaranteed.",11,"#81968A",false);
        note.setPadding(0,dp(22),0,0); page.addView(note);
    }

    private void compareHands(){
        int[] ar = read(aRank), br = read(bRank); String as = readSuits(aSuit), bs = readSuits(bSuit);
        int[] ah = score(ar,as), bh = score(br,bs);
        String winner = ah[0]>bh[0] || (ah[0]==bh[0] && ah[1]>bh[1]) ? "PLAYER A WINS" :
                ah[0]<bh[0] || (ah[0]==bh[0] && ah[1]<bh[1]) ? "PLAYER B WINS" : "TIE";
        String msg = winner+"\nA: "+handName(ah[0])+"  |  B: "+handName(bh[0]);
        result.setText(msg);
        history.add(0, "A "+cards(ar,as)+" vs B "+cards(br,bs)+" → "+winner);
        refreshHistory();
    }
    private int[] read(Spinner[] s){int[] x=new int[3]; for(int i=0;i<3;i++) x[i]=Arrays.asList(ranks).indexOf(s[i].getSelectedItem().toString())+2; return x;}
    private String readSuits(Spinner[] s){String x="";for(int i=0;i<3;i++)x+=s[i].getSelectedItem().toString();return x;}
    private int[] score(int[] r,String suitsText){
        int[] v=r.clone(); Arrays.sort(v); boolean flush=suitsText.charAt(0)==suitsText.charAt(1)&&suitsText.charAt(1)==suitsText.charAt(2);
        boolean trail=v[0]==v[2], straight=(v[1]==v[0]+1&&v[2]==v[1]+1)||(v[0]==2&&v[1]==3&&v[2]==14);
        int category=trail?6:(straight&&flush?5):(flush?4):(straight?3):(v[0]==v[1]||v[1]==v[2]?2:1);
        int high=trail?v[1]:v[2]; if(v[0]==2&&v[2]==14&&straight)high=3;
        if(category==2) high=(v[0]==v[1]?v[0]:v[1])*20+ (v[0]==v[1]?v[2]:v[0]);
        return new int[]{category,high};
    }
    private String handName(int n){String[] names={"High Card","Pair","Straight","Flush","Straight Flush","Trail / Three of a Kind"};return n==6?names[5]:names[n-1];}
    private String cards(int[] r,String s){String out="";for(int i=0;i<3;i++)out+=(i>0?" ":"")+ranks[r[i]-2]+s.charAt(i);return out;}
    private void refreshHistory(){String s="";for(int i=0;i<Math.min(history.size(),20);i++)s+=(i+1)+". "+history.get(i)+"\n";historyView.setText(s.isEmpty()?"No rounds saved yet.":s);}
    private void addSection(LinearLayout p,String t){TextView x=text(t,14,"#67D391",true);x.setPadding(0,dp(18),0,dp(8));p.addView(x);}
    private TextView text(String t,int size,String color,boolean bold){TextView v=new TextView(this);v.setText(t);v.setTextSize(size);v.setTextColor(Color.parseColor(color));if(bold)v.setTypeface(null,Typeface.BOLD);return v;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(48));p.setMargins(0,dp(3),0,dp(3));l.setLayoutParams(p);return l;}
    private Spinner spinner(String[] values){Spinner s=new Spinner(this);ArrayAdapter<String>a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,values);a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);s.setAdapter(a);return s;}
    private LinearLayout.LayoutParams weight(){return new LinearLayout.LayoutParams(0,dp(46),1);}
    private View space(int w){View v=new View(this);v.setLayoutParams(new LinearLayout.LayoutParams(dp(w),1));return v;}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density);}
}